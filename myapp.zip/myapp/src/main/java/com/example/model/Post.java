package com.example.model;

public class Post {
    private String title;
    private String description;
    private String content;
    private String timestamp;
    
    // Constructor
    public Post(String title, String description, String content, String timestamp) {
        this.title = title;
        this.description = description;
        this.content = content;
        this.timestamp = timestamp;
    }
    
    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
