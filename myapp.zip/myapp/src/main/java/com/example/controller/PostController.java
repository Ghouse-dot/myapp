package com.example.controller;

import com.example.model.Post;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class PostController extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Simulate post submission (title, description, content, timestamp)
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String content = request.getParameter("content");
        String timestamp = String.valueOf(System.currentTimeMillis());  // For simplicity, using current time as timestamp
        
        // Create Post object
        Post post = new Post(title, description, content, timestamp);
        
        // Set Post object as a request attribute
        request.setAttribute("post", post);
        
        // Forward the request to the JSP page (View)
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/post.jsp");
        dispatcher.forward(request, response);
    }
}
